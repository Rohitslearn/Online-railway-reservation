export class Book {
    pnr: string;
    ticket_id: string;
    no_of_seats: string;
    source: string;
    destination: string;
    date:string;
    price:string;
    time: string;

}
