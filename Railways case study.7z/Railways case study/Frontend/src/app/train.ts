export class Train {
       t_id: string;
       t_name:string ;
       source:string ;
       destination:string;
       price:string
}
